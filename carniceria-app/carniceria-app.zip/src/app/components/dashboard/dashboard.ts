import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class DashboardComponent implements OnInit {

  semanaInicio: string | null = null;

  totalSemana = 0;

  totalHistorico = 0;

  semanasRegistradas = 0;

  semanaActual: any[] = [];

  productoMasVendido: any = null;

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.cargarDashboard();
  }

  cargarDashboard(): void {
    this.api.getDashboard().subscribe({
      next: (data) => {

        this.semanaInicio = data.semana_inicio;

        this.totalSemana = data.total_semana;

        this.totalHistorico = data.total_historico;

        this.semanasRegistradas = data.semanas_registradas;

        this.semanaActual = data.semana_actual;

        this.productoMasVendido =
          data.producto_mas_vendido;
      },

      error: (err) => {
        console.error('Error cargando dashboard', err);
      }
    });
  }

  getBarHeight(valor: number): string {
    return `${valor * 5}px`;
  }

}