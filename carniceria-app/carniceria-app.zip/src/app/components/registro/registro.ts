import { Component } from '@angular/core';

import {
CommonModule
} from '@angular/common';

import {
FormsModule
} from '@angular/forms';

import { Router } from '@angular/router';

import {
ApiService
} from '../../services/api';

@Component({

selector:'app-registro',

standalone:true,

imports:[
CommonModule,
FormsModule
],

templateUrl:'./registro.html',
styleUrl:'./registro.css'

})

export class RegistroComponent{

usuario='';

password='';

mensaje='';

constructor(

private api:ApiService,

private router:Router

){}

registrar(){

if(
!this.usuario ||
!this.password
){

this.mensaje=
'Completa todos los campos';

return;

}

this.api.registrar({

usuar:this.usuario,
pass:this.password

})

.subscribe({

next:()=>{

alert(
'Usuario creado'
);

this.router.navigate(
['/login']
);

},

error:(err)=>{

this.mensaje=
err.error?.mensaje ||
'Error al crear usuario';

}

});

}

}