import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ProductosService } from '../../services/productos';
import { AuthService } from '../../services/auth';   

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './productos.html',
  styleUrls: ['./productos.css']
})
export class ProductosComponent implements OnInit {

  // ── ORIGINAL (no se tocó) ──────────────────
  productos: any[] = [];
  productosFiltrados: any[] = [];

  constructor(
    private productosService: ProductosService,
    private router: Router,
    private authService: AuthService   // ← NUEVO
  ) {}

  ngOnInit(): void {
    this.obtenerProductos();

    this.productosService.busqueda$.subscribe((texto: any) => {
      this.filtrarProductos(texto);
    });
  }

  obtenerProductos(): void {
    this.productosService.obtenerProductos()
      .subscribe({
        next: (data: any[]) => {
          this.productos = data;
          this.productosFiltrados = data;
        },
        error: (err: any) => {
          console.error('Error al obtener productos', err);
        }
      });
  }

  filtrarProductos(texto: any): void {
    if (typeof texto !== 'string' || !texto.trim()) {
      this.productosFiltrados = this.productos;
      return;
    }

    const textoLimpio = texto.toLowerCase();

    this.productosFiltrados = this.productos.filter((producto: any) =>
      (producto.nombre && producto.nombre.toLowerCase().includes(textoLimpio)) ||
      (producto.categoria && producto.categoria.toLowerCase().includes(textoLimpio))
    );
  }

  irLogin(): void {
    this.router.navigate(['/login']);
  }
  // ── FIN ORIGINAL ───────────────────────────


  // ── NUEVO - solo este getter ───────────────
  get autenticado(): boolean {
    return this.authService.estaAutenticado();
  }
  // ── FIN NUEVO ──────────────────────────────
}
