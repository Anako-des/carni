import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiService, InventarioItem } from '../../services/api';
import { ProductosService } from '../../services/productos';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-inventario',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './inventario.html',
  styleUrls: ['./inventario.css']
})
export class InventarioComponent implements OnInit, OnDestroy {

  productos: InventarioItem[] = [];
  cargando = true;
  error    = '';

  private todos: InventarioItem[] = [];
  private sub!: Subscription;

  constructor(
    private api: ApiService,
    private productosService: ProductosService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.api.getInventario().subscribe({
      next: (data) => {
        this.cargando  = false;
        this.todos     = data;
        this.productos = [...data];
      },
      error: () => {
        this.cargando = false;
        this.error = 'No se pudo cargar el inventario. ¿Está corriendo Flask?';
      }
    });

    this.sub = this.productosService.busqueda$.subscribe(texto => {
      if (!texto) {
        this.productos = [...this.todos];
      } else {
        this.productos = this.todos.filter(p =>
          p.nombre.toLowerCase().includes(texto)
        );
      }
    });
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  cerrarSesion(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}